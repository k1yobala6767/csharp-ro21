﻿using System;
using System.Globalization;

static bool TryReadDecimal(out decimal value)
{
    string? input = Console.ReadLine()?.Replace(',', '.');
    return decimal.TryParse(input, NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint
        | NumberStyles.AllowLeadingWhite | NumberStyles.AllowTrailingWhite,
        CultureInfo.InvariantCulture, out value);
}

if (!TryReadDecimal(out decimal balance) || balance < 0 ||
    !TryReadDecimal(out decimal rate) || rate < 0 ||
    !int.TryParse(Console.ReadLine(), out int years) || years < 0)
{
    Console.WriteLine("Некорректный ввод");
    return;
}

try
{
    for (long year = 1; year <= years; year++)
    {
        balance += balance * (rate / 100m);
        Console.WriteLine($"{year}: {balance:F2} тг");
    }
}
catch (OverflowException)
{
    Console.WriteLine("Сумма вклада слишком велика");
}
