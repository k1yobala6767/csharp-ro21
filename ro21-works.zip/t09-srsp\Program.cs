﻿using System;

if (!int.TryParse(Console.ReadLine(), out int limit))
{
    Console.WriteLine("Некорректный ввод");
    return;
}

bool first = true;
for (long number = 2; number <= limit; number++)
{
    bool prime = true;
    for (long divisor = 2; divisor * divisor <= number; divisor++)
    {
        if (number % divisor != 0) continue;
        prime = false;
        break;
    }

    if (!prime) continue;
    if (!first) Console.Write(' ');
    Console.Write(number);
    first = false;
}
Console.WriteLine();
