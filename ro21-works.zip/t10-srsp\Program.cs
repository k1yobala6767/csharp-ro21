﻿using System;

static int? ReadInt()
{
    while (true)
    {
        string? input = Console.ReadLine();
        if (input is null) return null;
        if (int.TryParse(input, out int value)) return value;
        Console.WriteLine("Введите целое число");
    }
}

static bool IsPrime(int number)
{
    if (number < 2) return false;
    for (int divisor = 2; divisor <= number / divisor; divisor++)
        if (number % divisor == 0) return false;
    return true;
}

int? limit = ReadInt();
if (limit is null) return;

bool first = true;
for (long number = 2; number <= limit.Value; number++)
{
    if (!IsPrime((int)number)) continue;
    if (!first) Console.Write(' ');
    Console.Write(number);
    first = false;
}
Console.WriteLine();
