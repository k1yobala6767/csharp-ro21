﻿using System;

if (!int.TryParse(Console.ReadLine(), out int value))
{
    Console.WriteLine("Некорректный ввод");
    return;
}

long number = Math.Abs((long)value);
int count = 0;
int sum = 0;
do
{
    sum += (int)(number % 10);
    count++;
    number /= 10;
} while (number != 0);

Console.WriteLine($"Количество цифр: {count}");
Console.WriteLine($"Сумма цифр: {sum}");
